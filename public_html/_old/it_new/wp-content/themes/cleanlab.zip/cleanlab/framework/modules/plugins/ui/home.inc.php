<?php

function zn_addons_page_home(){
	?>
		ADDONS HOME
	<?php
}