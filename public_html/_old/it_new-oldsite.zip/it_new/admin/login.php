<?php

require_once 'functions.php';

if(checkAdminLogin())
{
	$obj->redirect('index.php');
}

?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Communitec.co.uk - Admin Login</title>
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/styles.css" rel="stylesheet" type="text/css">
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/common.js" type="text/javascript"></script>
<script src="js/functions.js" type="text/javascript"></script>
</head>

<body>

	<div class="container">
        <header class="header">
        	<h1 class="logo"><a href="#">Communitec</a><br><span>admin panel</span></h1>
        </header>
        
        <div class="content_cont">
				
                <br><br><br>

                <div class="login_pane col-md-offset-2 col-md-8">
                    <div class="panel panel-default">
                        <div class="panel-heading"><h3 class="panel-title"><strong>Sign in </strong></h3></div>
                        <div class="panel-body">
                            
                                <div class="form-group">
                                    <label for="InputEmail1">Username</label>
                                    <input type="text" class="form-control" style="border-radius:0px" id="username" placeholder="Username">
                                </div>
                                <div class="form-group">
                                    <label for="InputPassword1">Password</label>
                                    <input type="password" class="form-control" style="border-radius:0px" id="password" placeholder="Password">
                                </div>
                                <button onclick="validateLogin()" class="btn btn-sm btn-primary">Sign in</button>
                                <span id="loginStatus"></span>
                            
                        </div>
                    </div>
                </div>  		
                

        </div><!--content_cont -->
        
        <footer class="footer">
        	<div class="foot_content">© Copyright 2014 - Communitec</div>
        </footer>
        
    </div><!-- container -->

</body>
</html>
