<nav class="left_nav">
				<a href="index.php">Home</a>
                <a href="about.php">About</a>				<a href="blog.php">Blog</a>
				<a href="services.php">Services</a>
                <a href="rates.php">Rates</a>		
				<a href="contact.php">Contact Us</a>	
                
            </nav><!--left_nav -->