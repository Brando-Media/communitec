<?php
class dataAccess{
/*private  $host = "localhost";
private  $user = "root";
private  $pass = "";
private  $db_name = "communitec";*/
private  $host = "localhost";
private  $user = "communitecit";
private  $pass = "Communitecit2016!";
private  $db_name = "communitecit";


private  $conn;
//mysql_connect("localhost", "root", "");
private static $m_pInstance = null;

	public static function getInstance()
	{
		if (!self::$m_pInstance)
		{
			self::$m_pInstance = new dataAccess();
		}
	
		return self::$m_pInstance;
	}
	
	
	
	function connect(){
	
	try{
	$this->conn = new PDO("mysql:dbname=".$this->db_name.";host=".$this->host.";", $this->user, $this->pass);//charset=utf8
	$this->conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
	$this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	
	}catch(PDOException  $e){
		echo $e->getMessage();
	}

	}


	function disconnect($conn){
	mysql_close($conn);	
	}
    function __construct(){
        
        
    }
    function __destruct(){
        
        
    }
    
    function insert($table,$arr=array()){
	
	$flds = implode(",",array_keys($arr));
	$vals = implode(",:",array_keys($arr));
	
	
	try{
	$this->connect();
	$query = "insert into ". $table ."(". $flds .")values(:".$vals.")";
	
	$stmt = $this->conn->prepare($query);
	$stmt->execute($arr);
	return $this->conn->lastInsertId('id');

	}catch(PDOException  $err){
		$this->p($err->getMessage(),"error");
		$this->p($err->getTrace(),"error");
	}
	
	return false;
	
    }//end update()
	
	
	function update($table,$qry,$arr=array()){
	
	try{
	$this->connect();
	$query = "UPDATE ". $table ." SET ". $qry;
	
	$stmt = $this->conn->prepare($query);
	
	$count = $stmt->execute($arr);
	
	return $count;

	}catch(PDOException  $err){
		$this->p($err->getMessage(),"error");
		$this->p($err->getTrace(),"error");
	}
	
	return $count;
	
    }//end update()


    function delete($table,$qry,$arr=array()){
	
	try{
	$this->connect();
	$query = "Delete From ". $table ." Where ". $qry;
	
	
	$stmt = $this->conn->prepare($query);
	$stmt->execute($arr);
	
	return true;

	}catch(PDOException  $err){
		$this->p($err->getMessage(),"error");
		$this->p($err->getTrace(),"error");
	}
	
	return false;
	
    }//end update()
	
	function query($qry,$arr=array()){
	
	try{
	$this->connect();
	$stmt = $this->conn->prepare($qry);
	$res = $stmt->execute($arr);
	
		if(strpos(strtolower($qry),"select")!==false){//echo " into select ";
		$res = $stmt->fetchAll($CONST);	
		}else if(strpos(strtolower($qry),"insert")!==false){//echo " into insert ";
		$res = $this->conn->lastInsertId('id');	
		}
		//echo " before return ";
	return $res;

	}catch(PDOException  $err){
		$this->p($err->getMessage(),"error");
		$this->p($err->getTrace(),"error");
	}
	
	return false;
	
    }//end update()

    function select($table,$fields,$condition='id>=:id',$arr=array(':id'=>'1'),$CONST=PDO::FETCH_ASSOC,$const_val=''){
	try{
	$this->connect();
	$query = "SELECT ". $fields ." FROM ". $table ." WHERE ".$condition."";
	
	$stmt = $this->conn->prepare($query);
	$stmt->execute($arr);
	if($const_val != ''){
	$rs = $stmt->fetchAll($CONST,$const_val);	
	}else{
	$rs = $stmt->fetchAll($CONST);	
	}
	
	}catch(PDOException  $err){
		$this->p($err->getMessage(),"error");
		$this->p($err->getTrace(),"error");
	}
	
        if(empty($rs)){
        return array();
        } else {
        return $rs;
        }
	//$this->disconnect($conn);
    }//end select()

	function select_count($table,$fields,$groupby){
	$conn=$this->connect();
    $query="Select  ". $fields ." from ". $table ." Group By  ".$groupby;
	//echo "<br>query =$query";
    $res=mysql_query($query);
        if(!$res){
        //echo "<br><font color=red>Problem during Record selection.</font>";
        }  else {
        return $res;
        }
	$this->disconnect($conn);
    }//end select()*/
	
	function max_id_record($table,$condition){
	$conn=$this->connect();
    $query="Select MAX(id) From ". $table ."  where ". $condition;
    $res=mysql_query($query);   
		if($res && $row=mysql_fetch_array($res)){
			$query2="Select * from $table where id={$row[0]}";
			 $res2=mysql_query($query2);  
			 if($res2){
			 return $res2;
			 }
			
		}	
	return 0;
    }//end update()
	
    function alert($a){
	echo "<script langauge=\"javascript\">alert(\"".$a."\");</script>";
    }//end function
    function redirect($url)
    {
            echo "<script langauge=\"javascript\">window.location = '$url';</script>";
    }// function end
	
	function deleteDir($dir) {
   	$iterator = new RecursiveDirectoryIterator($dir);
   	foreach (new RecursiveIteratorIterator($iterator, RecursiveIteratorIterator::CHILD_FIRST) as $file) 
   	{
      if ($file->isDir()) {
         rmdir($file->getPathname());
      } else {
         unlink($file->getPathname());
      }
   }
   rmdir($dir);
	}
	
      
    function insertContent($page_name){
		$rs =  $this->select("contents","*","page_name='$page_name' ");
if($row=mysql_fetch_array($rs)){
	$contents=$row['contents'];
	return $contents;
}
	}//end function
  
  	function stopDirectAccess($key,$value){
	if ($key != $value) { 
        die("<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">
<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"en\" xml:lang=\"en\">
<head>
<title>Access forbidden!</title>
<link rev=\"made\" href=\"mailto:postmaster@localhost\" />
<style type=\"text/css\"><!--/*--><![CDATA[/*><!--*/ 
    body { color: #000000; background-color: #FFFFFF; }
    a:link { color: #0000CC; }
    p, address {margin-left: 3em;}
    span {font-size: smaller;}
/*]]>*/--></style>
</head>
<body>
<h1>Access forbidden!</h1>
<p>
    You don't have permission to access the requested object.
    It is either read-protected or not readable by the server.
</p>
<p>
If you think this is a server error, please contact
the <a href=\"mailto:postmaster@localhost\">webmaster</a>.
</p>
<h2>Error 403</h2>
<address>
  <a href=\"/\">localhost</a><br />
  <span>1/20/2011 11:54:26 PM<br />
  Apache/2.2.14 (Win32) DAV/2 mod_ssl/2.2.14 OpenSSL/0.9.8l mod_autoindex_color PHP/5.3.1 mod_apreq2-20090110/2.7.1 mod_perl/2.0.4 Perl/v5.10.1</span>
</address>
</body>
</html>
"); //end die statement
}//end if
	}
	

function p($arr,$status = "normal"){
if($status == "error"){
echo "<font color=red><pre>";
print_r($arr);
echo "</pre></font>";	
}else{
echo "<font color=green><pre>";
print_r($arr);
echo "</pre></font>";		
}

}
  
}//end class dataAccess

//$obj = dataAccess::getInstance();
//$res = $obj->delete("comments","id=?",array(8));

//$obj->p($res);
?>