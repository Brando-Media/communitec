<?php
error_reporting(E_ALL ^ E_NOTICE);

if($_POST['page'])
{
$page = $_POST['page'];
$cur_page = $page;
$page -= 1;
$per_page = 5; // Per page records
$previous_btn = true;
$next_btn = true;
$first_btn = true;
$last_btn = true;
$class_pagination = "pagination";
$class_inactive = "inactive";
$class_active = "active";
$show_total = false;

$start = $page * $per_page;
include"db.php";
$query_pag_data = "SELECT * from slider LIMIT $start, $per_page";
$allImages = mysql_query($query_pag_data) or die('MySql Error' . mysql_error());
$msg = "";


?>



		
        
       			 <div class="table_cont">
            
                    <div class="table-responsive">
                    
                            
                          <table id="mytable" class="table table-bordred table-striped table-responsive">
                               
                            <thead>
                                
                                <th>Sr. No.</th>
                                <th>Thumbnail</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </thead>
                            
                            <tbody>
                           <?php if(mysql_num_rows($allImages) > 0):?> 
							<?php $serialCounter = 1;?>
                               <?php while($allImg = mysql_fetch_assoc($allImages)):?>
                                <tr>
                                    <td><?php echo $serialCounter; ?></td>
                                    
                                    <td><img src="../gallery/slider/thumb/<?php echo $allImg['thumb'];?>" width="150" /></td>
                                    <td><p><a href="slider_edit.php?action=edit&id=<?php echo $allImg['id'];?>"><button class="btn btn-primary btn-xs" data-title="Edit" data-placement="top" rel="tooltip">
                                        <i class="fa fa-edit"></i></button></a></p></td>
                                    <td><p><a href="?action=del&id=<?php echo $allImg['id']; ?>"><button class="btn btn-danger btn-xs" data-title="Delete" data-toggle="modal" data-target="#delete" data-placement="top" rel="tooltip"><i class="fa fa-trash-o"></i></button></a></p></td>
                                </tr>
                                <?php $serialCounter++;?>
                           <?php endwhile; ?>
                                                             
                          <?php else: ?>
                          	<?php echo "<tr><td colspan='5' align='center'>No record found.</td></tr>";?>
                          <?php endif;?>                                    
                            
                            </tbody>
                    
            </table>
            
            <div class="clearfix"></div>
            



<?php



/* -----Total count--- */
$query_pag_num = "SELECT COUNT(*) AS count FROM slider"; // Total records
$result_pag_num = mysql_query($query_pag_num);
$row = mysql_fetch_array($result_pag_num);
$count = $row['count'];
$no_of_paginations = ceil($count / $per_page);
/* -----Calculating the starting and endign values for the loop----- */

// CALCULATE BEGIN AND END VALUE OF LOOPS
        if ($cur_page >= 7) {
            $start_loop = $cur_page - 3;
            if ($no_of_paginations > $cur_page + 3)
                $end_loop = $cur_page + 3;
            else if ($cur_page <= $no_of_paginations && $cur_page > $no_of_paginations - 6) {
                $start_loop = $no_of_paginations - 6;
                $end_loop = $no_of_paginations;
            } else {
                $end_loop = $no_of_paginations;
            }
        } else {
            $start_loop = 1;
            if ($no_of_paginations > 7)
                $end_loop = 7;
            else
                $end_loop = $no_of_paginations;
        }
        
        // // ADD STRING TO RESULT SO WE CAN DISPLAY FIRST BUTTON 
        $msg .= "<ul id='paginations' class='pagination pull-right'>";
        if ($first_btn && $cur_page > 1) {
            $msg .= "<li p='1'><a href='javascript:void(0)'>First</a></li>";
        } else if ($first_btn) {
            $msg .= "<li p='1' class='disabled'><a href='javascript:void(0)'>First</a></li>";
        }
    
        // SHOW PREVIOUS BUTTON
        if ($previous_btn && $cur_page > 1) {
            $pre = $cur_page - 1;
            $msg .= "<li p='$pre'><a href='javascript:void(0)'><i class='fa fa-chevron-left'></i></a></li>";
        } else if ($previous_btn) {
            $msg .= "<li class='disabled'><a href='javascript:void(0)'><i class='fa fa-chevron-left'></i></a></li>";
        }
        for ($i = $start_loop; $i <= $end_loop; $i++) {
        
            if ($cur_page == $i)
                $msg .= "<li p='$i' class='active'><a href='javascript:void(0)'>{$i}</a></li>";
            else
                $msg .= "<li p='$i'><a href='javascript:void(0)'>{$i}</a></li>";
        }
        
        // SHOW NEXT BUTTON
        if ($next_btn && $cur_page < $no_of_paginations) {
            $nex = $cur_page + 1;
            $msg .= "<li p='$nex'><a href='javascript:void(0)'><i class='fa fa-chevron-right'></i></a></li>";
        } else if ($next_btn) {
            $msg .= "<li class='disabled'><a href='javascript:void(0)'><i class='fa fa-chevron-right'></i></a></li>";
        }
        
        // SHOW LAST BUTTON
        if ($last_btn && $cur_page < $no_of_paginations) {
            $msg .= "<li p='$no_of_paginations'><a href='javascript:void(0)'>Last</a></li>";
        } else if ($last_btn) {
            $msg .= "<li p='$no_of_paginations' class='disabled'><a href='javascript:void(0)'>Last</a></li>";
        }
        
        // SHOW TEXTBOX TO PAGE INPUT
        if($show_goto)
            $goto = "<input type='text' id='goto' class='$class_txt_goto' size='1' style='margin-top:-1px;margin-left:40px;margin-right:10px'/><input type='button' id='go_btn' class='$class_go_button' value='Đến'/>";
        if($show_total)
            $total_string = "<span id='total' class='$class_text_total' a='$no_of_paginations'>Page <b>" . $cur_page . "</b>/<b>$no_of_paginations</b></span>";
        $stradd =  $total_string;
        
        // RETURN RESULT
       echo $msg . "</ul>" . $stradd. "</div>
                        
                    </div>";
}
?>
