<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
require_once 'classes/dataAccess.php';

$obj = dataAccess::getInstance();


if(isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id']) && $_GET['id'] != '')
{
	$id = $_GET['id'];
	$editImage = $obj->select("services","*","id=?",array($id));
}
else
{
	$obj->redirect("services.php");	
}

if(isset($_POST['Submit']))

{
	$title = $_POST['title'];
	$sub_title = $_POST['sub_title'];
	$main_title = $_POST['main_title'];
	$details = $_POST['details'];
	$size = 150; // the thumbnail height

	$filedir = '../gallery/services/full/'; // the directory for the original image
	$thumbdir = '../gallery/services/thumb/'; // the directory for the thumbnail image
	$prefix = 'thumb_'; // the prefix to be added to the original name

	$maxfile = '2000000';
	$mode = '0666';
	
	$userfile_name = $_FILES['image']['name'];
	$userfile_tmp = $_FILES['image']['tmp_name'];
	$userfile_size = $_FILES['image']['size'];
	$userfile_type = $_FILES['image']['type'];
	
	if (isset($_FILES['image']['name']) && $_FILES['image']['name'] != '') 
	{
		$prod_img = $filedir.$userfile_name;

		$prod_img_thumb = $thumbdir.$prefix.$userfile_name;
		$imageMoved = move_uploaded_file($userfile_tmp, $prod_img);
		chmod ($prod_img, octdec($mode));
		
		$sizes = getimagesize($prod_img);
		$type = $sizes[2];
		$aspect_ratio = $sizes[1]/$sizes[0]; 

		/*if ($sizes[1] <= $size)
		{
			$new_width = $sizes[0];
			$new_height = $sizes[1];
		}else{
			$new_height = $size;
			$new_width = abs($new_height/$aspect_ratio);
		}*/
		
		$new_width = $sizes[0];
		$new_height = $sizes[1];

		$destimg=ImageCreateTrueColor($new_width,$new_height)
			or die('Problem In Creating image');
		if ($type == 1)
		{
			$srcimg = imagecreatefromgif($prod_img);
		}
		elseif ($type == 2)
		{
			$srcimg = imagecreatefromjpeg($prod_img);
		}
		elseif ($type == 3)
		{
			$srcimg = imagecreatefrompng($prod_img);
		}
		else
		{
			$srcimg = imagecreatefromwbmp($prod_img);
		}

		//$srcimg=ImageCreateFromJPEG($prod_img)
			//or die('Problem In opening Source Image');
		if(function_exists('imagecopyresampled'))
		{
			imagecopyresampled($destimg,$srcimg,0,0,0,0,$new_width,$new_height,ImageSX($srcimg),ImageSY($srcimg))
			or die('Problem In resizing');
		}else{
			Imagecopyresized($destimg,$srcimg,0,0,0,0,$new_width,$new_height,ImageSX($srcimg),ImageSY($srcimg))
			or die('Problem In resizing');
		}
		
		if ($type == 1)
		{
			imagegif($destimg,$prod_img_thumb,90)
			or die('Problem In saving');
		}
		elseif ($type == 2)
		{
			imagejpeg($destimg,$prod_img_thumb,90)
			or die('Problem In saving');
		}
		elseif ($type == 3)
		{
			imagepng($destimg,$prod_img_thumb,90)
			or die('Problem In saving');
		}
		else
		{
			imagewbmp($destimg,$prod_img_thumb,90)
			or die('Problem In saving');
		}
		imagedestroy($destimg);
		
		if($imageMoved)
		{
			$thumbpath = $prefix.$userfile_name;
			$imagesdb = $obj->update("services","main_title='$main_title',title = '$title', sub_title = '$sub_title', thumb = '$thumbpath' , full = '$userfile_name', details = '$details' where id = ?",array($id));
			
			if($imagesdb)
			{
				$addMsg = "Record updated successfully";	
			}
		}
		
	}
	else
	{
		$imagesdb = $obj->update("services","main_title='$main_title', title = '$title', sub_title = '$sub_title', details = '$details' where id=?",array($id));
		if($imagesdb)
			{
				$addMsg = "Record updated successfully";	
			}
	}

$obj->redirect('services.php');

}




?>
<?php
include_once('header.php');
?>


        <div class="content_cont">
        	
            <?php include_once('left.php');?>
            
            <div class="admin_contents">
			
            <?php echo $addMsg; ?>

			<h4>Services</h4> 

			
            <form method="post" action="" name="home" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="text_field">Service Title</label>
                    <input type="text" name="title" value="<?php echo $editImage[0]['title'];?>" class="form-control" id="text_field" placeholder="Image Title">
                </div>
                
                <div class="form-group">
                    <label for="text_field">Main Title</label>
                    <input type="text" name="main_title" value="<?php echo $editImage[0]['main_title'];?>" class="form-control" id="main_title" placeholder="Main Title">
                </div>
                
                <div class="form-group">
                    <label for="text_field">Service Sub Title</label>
                    <input type="text" name="sub_title" value="<?php echo $editImage[0]['sub_title'];?>"  class="form-control" id="sub_title" placeholder="Service Sub Title">
                </div>
                
                <div class="form-group">
                    <label for="exampleInputFile">Image</label>
                    <input type="file" id="image" name="image"><span><img src="../gallery/services/thumb/<?php echo $editImage[0]['thumb'];?>"></span>
                    <p class="help-block">*ext .png, .jpg, .gif</p>
                </div>
               
                        <label for="contents">Details:</label>
                <textarea class="form-control ckeditor" name="details" id="details" rows="5"><?php echo $editImage[0]['details'];?></textarea>  
                <br><br>   
                <input type="submit" name="Submit" class="btn btn-primary" value="Update" /> 
                               
            </form>   
        


			
                
            </div><!--admin_contents -->
        </div><!--content_cont -->
        
       <?php include_once('footerc.php');?>
        
    </div><!-- container -->

</body>
</html>
