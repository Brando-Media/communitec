<?php


error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);

function checkAdminLogin()
{
	if($_SESSION['username'] != '')
	{
		return true;	
	}
	else
	{
		return false;	
	}
}

function dataFilter($data){
   $data = trim(htmlentities(strip_tags($data)));
       if (get_magic_quotes_gpc())
         {$data = stripslashes($data);}else{
      $data = mysql_real_escape_string($data);}
     return $data;
 } function redirect($url)    {            echo "<script langauge=\"javascript\">window.location = '$url';</script>";    }// function end
 

?>