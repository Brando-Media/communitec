<?php session_start();

error_reporting(E_ALL ^ E_NOTICE);



require_once 'admin/classes/dataAccess.php';

include("php/simple-php-captcha/simple-php-captcha.php");
$obj = dataAccess::getInstance();
$blog_content = $obj->query("SELECT *FROM blog ORDER BY upload_date DESC");
//echo $blog_content[0]['title']; exit;
//echo '<pre>'; print_r($blog_content); exit;
 ?>
<!DOCTYPE html>
<html>
	<head>

		<!-- Basic -->
		<meta charset="utf-8">
       
		<title>Communitec</title>		
		
		<meta name="keywords" content="HTML5 Template" />

		<meta name="description" content="Communitec">

		<meta name="author" content="communitec.co.uk">

		<!-- Favicon -->
		<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon" />
		<link rel="apple-touch-icon" href="img/apple-touch-icon.png">

		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- Web Fonts  -->
		<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800%7CShadows+Into+Light" rel="stylesheet" type="text/css">

		<!-- Vendor CSS -->
		<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.css">
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.css">
		<link rel="stylesheet" href="vendor/owlcarousel/owl.carousel.min.css" media="screen">
		<link rel="stylesheet" href="vendor/owlcarousel/owl.theme.default.min.css" media="screen">
		<link rel="stylesheet" href="vendor/magnific-popup/magnific-popup.css" media="screen">

		<!-- Theme CSS -->
		<link rel="stylesheet" href="css/theme.css">
		<link rel="stylesheet" href="css/theme-elements.css">
		<link rel="stylesheet" href="css/theme-blog.css">
		<link rel="stylesheet" href="css/theme-shop.css">
		<link rel="stylesheet" href="css/theme-animate.css">

		<!-- Skin CSS -->
		<link rel="stylesheet" href="css/skins/default.css">

		<!-- Theme Custom CSS -->
		<link rel="stylesheet" href="css/custom.css">

		<!-- Head Libs -->
		<script src="vendor/modernizr/modernizr.js"></script>
		
		<!-- Responsive CSS -->

		<link rel="stylesheet" href="css/theme-responsive.css" />

		<!--[if IE]>
			<link rel="stylesheet" href="css/ie.css">
		<![endif]-->

		<!--[if lte IE 8]>
			<script src="vendor/respond/respond.js"></script>
			<script src="vendor/excanvas/excanvas.js"></script>
		<![endif]-->

	</head>
	<body>

		<div class="body">
			<header id="header" class="single-menu flat-menu">

				<div class="container">

					<h1 class="logo">

						<a href="index.php">

							<img alt="Porto" width="111" height="54" data-sticky-width="82" data-sticky-height="40" src="img/logo.png">

						</a>

					</h1>

					<button class="btn btn-responsive-nav btn-inverse" data-toggle="collapse" data-target=".nav-main-collapse">

						<i class="icon icon-bars"></i>

					</button>

				</div>

				<div class="navbar-collapse nav-main-collapse collapse">

					<div class="container">

						<ul class="social-icons">

							<li class="facebook"><a href="http://www.facebook.com/communitec" target="_blank" title="Facebook">Facebook</a></li>

							<li class="twitter"><a href="http://www.twitter.com/communitecltd" target="_blank" title="Twitter">Twitter</a></li>

							<li class="linkedin"><a href="http://www.linkedin.com/communitec" target="_blank" title="Linkedin">Linkedin</a></li>

						</ul>

						<nav class="nav-main">

							<ul class="nav nav-pills nav-main" id="mainMenu">

								<li class="dropdown active">

									<a data-hash href="index.php">

										Home

										

									</a>

								</li>

                                <li>

									<a data-hash href="index.php">About Us</a>

								</li>
								
								
                                <li>

									<a  href="blog.php">Blog</a>

								</li>


								<li>

									<a data-hash href="index.php">Services</a>

								</li>

								

								<li>

									<a data-hash href="index.php">Rates</a>

								</li>

								<li>

									<a data-hash href="index.php">Contact Us</a>

								</li>

							</ul>

						</nav>

					</div>

				</div>

			</header>

			<div role="main" class="main">

				<section class="page-header">
					<div class="container">
						
						<div class="row">
							<div class="col-md-12">
								<h1>Blog</h1>
							</div>
						</div>
					</div>
				</section>
		
				<div class="container">

					<div class="row">
						<div class="col-md-12">
							<div class="blog-posts">
								<section class="timeline">
									<div class="timeline-body">
								<?php $months = array();
								$counter = 1;
								foreach($blog_content as $blog):
								
								?>
								
									
										<?php 
										$monstr = explode("-",$blog['upload_date']);
										$month_year = $monstr[0]."-".$monstr[1];
										?>
										<?php if(in_array($month_year, $months) === FALSE):?>
											<div class="timeline-date">
										
												<h3 class="heading-primary"><?php $time = strtotime($blog['upload_date']);
																				  $month=date("F",$time); 
																				  $year=date("Y",$time); 
																				  echo $month.' '.$year;?></h3>
											</div>
											<?php $months[] = $month_year;
											$counter = 1;
											?>
										<?php endif;?>
										
										
										<article class="timeline-box <?php if($counter%2==0) { echo 'right '; } else { echo 'left '; }?> post post-medium">
											<div class="row">

												<div class="col-md-12">
													<div class="post-image">
														<div class="owl-carousel" data-plugin-options='{"items":1}'>
															<div>
																<div class="img-thumbnail">
																	<img class="img-responsive" src="img/blog/blog-image-1.jpg" alt="">
																</div>
															</div>
															<div>
																<div class="img-thumbnail">
																	<img class="img-responsive" src="img/blog/blog-image-2.jpg" alt="">
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-12">

													<div class="post-content">
														<h4 class="heading-primary"><a href="blog-post.html"><?php echo $blog['title']; ?></a></h4>
														<p><?php echo $blog['details']; ?> </p>
													</div>

												</div>
											</div>
											<div class="row">
												<div class="col-md-12">
													<div class="post-meta">
														<span><i class="fa fa-calendar"></i> January 10, 2013 </span><br>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-12">
													<div class="post-meta">
														<span><i class="fa fa-user"></i> By <a href="#">John Doe</a> </span>
														<span><i class="fa fa-tag"></i> <a href="#">Duis</a>, <a href="#">News</a> </span>
														<span><i class="fa fa-comments"></i> <a href="#">12 Comments</a></span>
													</div>
												</div>
											</div>
											<div class="row">
												<div class="col-md-12">
													<a href="blog-post.html" class="btn btn-xs btn-primary pull-right">Read more...</a>
												</div>
											</div>

										</article>
									
										
										

									

								
											
											
								<?php 
									  $counter++;
						endforeach; 
						//echo '<pre>'; print_r($months); exit; 		?>
									</div>
								</section>
							</div>
						</div>

					</div>

				</div>

			</div>

			<footer id="footer">
				<div class="container">
					<div class="row">
						<div class="footer-ribbon">
							<span>Get in Touch</span>
						</div>
						<div class="col-md-3">
							<div class="newsletter">
								<h4 class="heading-primary">Newsletter</h4>
								<p>Keep up on our always evolving product features and technology. Enter your e-mail and subscribe to our newsletter.</p>
			
								<div class="alert alert-success hidden" id="newsletterSuccess">
									<strong>Success!</strong> You've been added to our email list.
								</div>
			
								<div class="alert alert-danger hidden" id="newsletterError"></div>
			
								<form id="newsletterForm" action="php/newsletter-subscribe.php" method="POST">
									<div class="input-group">
										<input class="form-control" placeholder="Email Address" name="newsletterEmail" id="newsletterEmail" type="text">
										<span class="input-group-btn">
											<button class="btn btn-default" type="submit">Go!</button>
										</span>
									</div>
								</form>
							</div>
						</div>
						<div class="col-md-3">
							<h4 class="heading-primary">Latest Tweets</h4>
							<div id="tweet" class="twitter" data-plugin-tweets data-plugin-options='{"username": "", "count": 2}'>
								<p>Please wait...</p>
							</div>
						</div>
						<div class="col-md-4">
							<div class="contact-details">
								<h4 class="heading-primary">Contact Us</h4>
								<ul class="contact">
									<li><p><i class="fa fa-map-marker"></i> <strong>Address:</strong> 1234 Street Name, City Name, United States</p></li>
									<li><p><i class="fa fa-phone"></i> <strong>Phone:</strong> (123) 456-7890</p></li>
									<li><p><i class="fa fa-envelope"></i> <strong>Email:</strong> <a href="mailto:mail@example.com">mail@example.com</a></p></li>
								</ul>
							</div>
						</div>
						<div class="col-md-2">
							<h4 class="heading-primary">Follow Us</h4>
							<div class="social-icons">
								<ul class="social-icons">
									<li class="facebook"><a href="http://www.facebook.com/" target="_blank" data-placement="bottom" data-tooltip title="Facebook">Facebook</a></li>
									<li class="twitter"><a href="http://www.twitter.com/" target="_blank" data-placement="bottom" data-tooltip title="Twitter">Twitter</a></li>
									<li class="linkedin"><a href="http://www.linkedin.com/" target="_blank" data-placement="bottom" data-tooltip title="Linkedin">Linkedin</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="footer-copyright">
					<div class="container">
						<div class="row">
							<div class="col-md-1">
								<a href="index.html" class="logo">
									<img alt="Porto Website Template" class="img-responsive" src="img/logo-footer.png">
								</a>
							</div>
							<div class="col-md-7">
								<p>© Copyright 2015. All Rights Reserved.</p>
							</div>
							<div class="col-md-4">
								<nav id="sub-menu">
									<ul>
										<li><a href="page-faq.html">FAQ's</a></li>
										<li><a href="sitemap.html">Sitemap</a></li>
										<li><a href="contact-us.html">Contact</a></li>
									</ul>
								</nav>
							</div>
						</div>
					</div>
				</div>
			</footer>
		</div>

		<!-- Vendor -->
		<!--[if lt IE 9]>
		<script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
		<![endif]-->
		<!--[if gte IE 9]><!-->
		<script src="vendor/jquery/jquery.js"></script>
		<!--<![endif]-->
		<script src="vendor/jquery.appear/jquery.appear.js"></script>
		<script src="vendor/jquery.easing/jquery.easing.js"></script>
		<script src="vendor/jquery-cookie/jquery-cookie.js"></script>
		<script src="vendor/bootstrap/bootstrap.js"></script>
		<script src="vendor/common/common.js"></script>
		<script src="vendor/jquery.validation/jquery.validation.js"></script>
		<script src="vendor/jquery.stellar/jquery.stellar.js"></script>
		<script src="vendor/jquery.easy-pie-chart/jquery.easy-pie-chart.js"></script>
		<script src="vendor/jquery.gmap/jquery.gmap.js"></script>
		<script src="vendor/isotope/jquery.isotope.js"></script>
		<script src="vendor/owlcarousel/owl.carousel.js"></script>
		<script src="vendor/jflickrfeed/jflickrfeed.js"></script>
		<script src="vendor/magnific-popup/jquery.magnific-popup.js"></script>
		<script src="vendor/vide/vide.js"></script>
		
		<!-- Theme Base, Components and Settings -->
		<script src="js/theme.js"></script>
		
		<!-- Theme Custom -->
		<script src="js/custom.js"></script>
		
		<!-- Theme Initialization Files -->
		<script src="js/theme.init.js"></script>

		<!-- Google Analytics: Change UA-XXXXX-X to be your site's ID. Go to http://www.google.com/analytics/ for more information.
		<script type="text/javascript">
		
			var _gaq = _gaq || [];
			_gaq.push(['_setAccount', 'UA-12345678-1']);
			_gaq.push(['_trackPageview']);
		
			(function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
			})();
		
		</script>
		 -->

	</body>
</html>
