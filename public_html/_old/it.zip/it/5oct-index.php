<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);

require_once 'admin/classes/dataAccess.php';
include("php/simple-php-captcha/simple-php-captcha.php");

$obj = dataAccess::getInstance();

$home = $obj->select("home","*","id = ?",array(1));

$aboutus = $obj->select("aboutus","*","id = ?",array(1));$blog = $obj->select("blog","*","id = ?",array(1));

$services = $obj->select("services","*","id > ?",array(0));

$rates = $obj->select("rates","*","id = ?",array(1));

$contactus = $obj->select("contactus","*","id = ?",array(1));

?>
<!DOCTYPE html>
<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->
<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->
	<head>

		<!-- Basic -->
		<meta charset="utf-8">
		<title>Communitec</title>		
		<meta name="keywords" content="HTML5 Template" />
		<meta name="description" content="Communitec">
		<meta name="author" content="communitec.co.uk">

		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- Web Fonts  -->
		<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800%7CShadows+Into+Light" rel="stylesheet" type="text/css">

		<!-- Libs CSS -->
		<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.css">
		<link rel="stylesheet" href="vendor/font-awesome/css/font-awesome.css">
		<link rel="stylesheet" href="vendor/owl-carousel/owl.carousel.css" media="screen">
		<link rel="stylesheet" href="vendor/owl-carousel/owl.theme.css" media="screen">
		<link rel="stylesheet" href="vendor/magnific-popup/magnific-popup.css" media="screen">
		<link rel="stylesheet" href="vendor/isotope/jquery.isotope.css" media="screen">
		<link rel="stylesheet" href="vendor/mediaelement/mediaelementplayer.css" media="screen">

		<!-- Theme CSS -->
		<link rel="stylesheet" href="css/theme.css">
		<link rel="stylesheet" href="css/theme-elements.css">
		<link rel="stylesheet" href="css/theme-blog.css">
		<link rel="stylesheet" href="css/theme-shop.css">
		<link rel="stylesheet" href="css/theme-animate.css">

		<!-- Current Page CSS -->
		<link rel="stylesheet" href="vendor/rs-plugin/css/settings.css" media="screen">
		<link rel="stylesheet" href="vendor/circle-flip-slideshow/css/component.css" media="screen">

		<!-- Responsive CSS -->
		<link rel="stylesheet" href="css/theme-responsive.css" />

		<!-- Skin CSS -->
		<link rel="stylesheet" href="css/skins/default.css">

		<!-- Custom CSS -->
		<link rel="stylesheet" href="css/custom.css">

		<!-- Head Libs -->
		<script src="vendor/modernizr.js"></script>

		<!--[if IE]>
			<link rel="stylesheet" href="css/ie.css">
		<![endif]-->

		<!--[if lte IE 8]>
			<script src="vendor/respond.js"></script>
		<![endif]-->

	</head>
	<body class="one-page" data-target=".single-menu" data-spy="scroll" data-offset="200">

		<div class="body">
			<header id="header" class="single-menu flat-menu">
				<div class="container">
					<h1 class="logo">
						<a href="index.php">
							<img alt="Porto" width="111" height="54" data-sticky-width="82" data-sticky-height="40" src="img/logo.png">
						</a>
					</h1>
					<button class="btn btn-responsive-nav btn-inverse" data-toggle="collapse" data-target=".nav-main-collapse">
						<i class="icon icon-bars"></i>
					</button>
				</div>
				<div class="navbar-collapse nav-main-collapse collapse">
					<div class="container">
						<ul class="social-icons">
							<li class="facebook"><a href="http://www.facebook.com/communitec" target="_blank" title="Facebook">Facebook</a></li>
							<li class="twitter"><a href="http://www.twitter.com/communitecltd" target="_blank" title="Twitter">Twitter</a></li>
							<li class="linkedin"><a href="https://www.linkedin.com/company/communitec-ltd" target="_blank" title="Linkedin">Linkedin</a></li>
						</ul>
						<nav class="nav-main">
							<ul class="nav nav-pills nav-main" id="mainMenu">
								<li class="dropdown active">
									<a data-hash href="#home">
										Home
										
									</a>
								</li>
                                <li>
									<a data-hash href="#about">About Us</a>
								</li>																                                <li>									<a  href="blog.php">Blog</a>								</li>
								<li>
									<a data-hash href="#services">Services</a>
								</li>
								
								<li>
									<a data-hash href="#rates">Rates</a>
								</li>
								<li>
									<a data-hash href="#contactus">Contact Us</a>
								</li>
							</ul>
						</nav>
					</div>
				</div>
			</header>

			<div role="main" class="main">

				<div class="slider-container slider-container-fullscreen hidden-xs">
					<div class="slider" id="revolutionSliderFullScreen">
						<ul>
							<li data-transition="fade" data-slotamount="10" data-masterspeed="300">
								<img src="img/slides/Home.jpg" data-fullwidthcentering="on" alt="">

									<!--<div class="tp-caption sft stb visible-lg"
										 data-x="320"
										 data-y="100"
										 data-speed="300"
										 data-start="1000"
										 data-easing="easeOutExpo"><img src="img/slides/slide-title-border.png" alt=""></div>-->

									<div class="tp-caption top-label lfl stl"
										 data-x="365"
										 data-y="100"
										 data-speed="300"
										 data-start="500"
										 data-easing="easeOutExpo">Looking for technology assistance?</div>

									<!--<div class="tp-caption sft stb visible-lg"
										 data-x="870"
										 data-y="100"
										 data-speed="300"
										 data-start="1000"
										 data-easing="easeOutExpo"><img src="img/slides/slide-title-border.png" alt=""></div>-->

									<div class="tp-caption main-label sft stb"
										 data-x="425"
										 data-y="140"
										 data-speed="300"
										 data-start="1500"
										 data-easing="easeOutExpo">Look no further</div>

									<!--<div class="tp-caption bottom-label sft stb"
										 data-x="430"
										 data-y="200"
										 data-speed="500"
										 data-start="2000"
										 data-easing="easeOutExpo">Check out our options and features.</div>-->

									<div class="tp-caption sft stb center-caption"
										 data-x="0"
										 data-y="230"
										 data-speed="300"
										 data-start="2500"
										 data-easing="easeOutExpo"><a data-hash href="#services" class="btn btn-lg btn-primary main-button">Get Started Now!</a></div>


							</li>
						</ul>
					</div>
                    
				</div>
                <hr class="tall" />
                    
				
                
                
                <div class="container">

					<div class="row center" id="home">
						<div class="col-md-12" style="text-align:left">
							<!--<h2 class="short word-rotator-title">
								Communitec provide
								<strong class="inverted" data-appear-animation="bounceIn">
									<span class="word-rotate">
										<span class="word-rotate-items">
											<span>cooperative</span>
											<span>friendly</span>
											<span>quick</span>
										</span>
									</span>
								</strong>
								 support.</h2>-->
                                 
                                 <?php echo $home[0]['content'];?>
							<!--<p class="featured lead">
								Communitec is a provider of friendly and professional technology services for everyone from home users to small and medium sized businesses in London.</p> <p class="featured lead">
We offer a full service solution of IT support, maintenance, consultancy, telecoms and Audio/Visual.
Our aim is to always take care of you, efficiently, effectively and at the right price.</p> <p class="featured lead">
We love what we do and are always looking for ways to improve our services and bring more benefits to our customers. Keeping up with the latest improvements in technology ensures we can advise you on the best solution for your particular needs. We understand that not everyone wants to know all the details of their IT, but everyone wants it to work!</p>-->

                              
						</div>
					</div>

					<hr class="tall" />
				</div>
                
                
                <!-- //end home -->

				<section class="parallax" data-stellar-background-ratio="0.5" style="background-image: url(img/parallax.jpg);">
					<div class="container">
						<div class="row center">
							<div class="col-md-12">
								<i class="icon icon-featured icon-info" data-appear-animation="bounceIn"></i>
								<h1 class="short white text-shadow big bold" data-appear-animation="fadeInUp"><strong>Do you know us?</strong></h1>
							</div>
						</div>
					</div>
				</section>


				<div class="container">

					<div class="row center" id="about">
						<div class="col-md-12" style="text-align:left">
							
                             <?php echo $aboutus[0]['content'];?>
							<!--<p class="featured lead">
								Founded by Rory Hackett and working under the name of Home Network Help for several years, Communitec Ltd continues the provision of highly skilled and cost effective technology solutions. </p>
                                <p class="featured lead">
Over the past 9 years, the business has expanded naturally as a result of referrals; there is nothing better than word of mouth marketing and we pride ourselves on 100% customer satisfaction. </p><p class="featured lead">
We understand that it can be unnerving allowing someone unknown into your home or business, so our engineers are trained to ensure that they are professional, knowledgeable and courteous at all times.</p><p class="featured lead">
Our customers continue to return to us over time, whether for maintenance or as their needs increase and we are delighted by their glowing testimonials.

							</p>-->
						</div>
					</div>

					<hr class="tall" />
				</div>
				
                
                
                <section class="highlight top">
					<div class="container">
						<div class="row" id="services">
							<div class="col-md-12">
								<h1><strong>Services</strong></h1>

								<div class="owl-carousel owl-carousel-spaced" data-plugin-options='{"items": 4, "singleItem": false, "autoHeight": true}'>
							<?php $counter = 0;?>
                            <?php foreach((array)$services as $service):?>
                                <?php $counter++; ?>
                                	<div>
										<div class="portfolio-item img-thumbnail">
											<a class="thumb-info lightbox" href="#popupProject<?php echo $counter;?>" data-plugin-options='{"type":"inline", preloader: false}'>
												<img alt="" class="img-responsive" src="gallery/services/thumb/<?php echo $service['thumb']; ?>">
												<span class="thumb-info-title">
													<span class="thumb-info-inner"><?php echo $service['main_title']?></span>
													<span class="thumb-info-type"><?php echo $service['sub_title']?></span>
												</span>
												<span class="thumb-info-action">
													<span title="Universal" class="thumb-info-action-icon"><i class="icon icon-link"></i></span>
												</span>
											</a>
										</div>
										<div id="popupProject<?php echo $counter;?>" class="popup-inline-content">
											<h2><?php echo $service['title']?></h2>

											<div class="row">
												<div class="col-md-6">
													<img class="img-thumbnail img-responsive" alt="" src="gallery/services/full/<?php echo $service['full']; ?>">
												</div>
												<div class="col-md-6">

													<?php echo $service['details'];?>

												</div>
											</div>
										</div>
									</div>
									
                                    
                           <?php endforeach; ?>         
                                    
                                    
                                    
                                    
                                    
                                   
								
								</div>
							</div>
						</div>
					</div>
				</section>
                

				
                <div class="container">

					<div class="row center" id="rates">
						<div class="col-md-12" style="text-align:left">
							<?php echo $rates[0]['content'];?>
						</div>
					</div>

					<hr class="tall" />
				</div>
                
                
				<section class="parallax" data-stellar-background-ratio="0.5" style="background-image: url(img/parallax-transparent.jpg);">
					<div class="container">
						<div class="row center">
							<div class="col-md-12">
								<i class="icon icon-featured icon-envelope" data-appear-animation="bounceIn"></i>
								<h1 class="short text-shadow big bold" data-appear-animation="fadeInUp"><strong>Get in Touch With Us</strong></h1>
							</div>
						</div>
					</div>
				</section>

				<!-- Google Maps -->
				<div id="googlemaps" class="google-map push-top"></div>

				<div class="container">

					<div class="row" id="contact">
						<div class="col-md-6">

							<div class="alert alert-success hidden" id="contactSuccess">
								<strong>Success!</strong> Your message has been sent to us.
							</div>

							<div class="alert alert-danger hidden" id="contactError">
								<strong>Error!</strong> There was an error sending your message.
							</div>

							<h2 class="short"><strong>Contact</strong> Us</h2>
							<form action="php/contact-form.php" id="contactForm" type="post">
								<div class="row">
									<div class="form-group">
										<div class="col-md-6">
											<label>Your name *</label>
											<input type="text" value="" data-msg-required="Please enter your name." maxlength="100" class="form-control" name="name" id="name">
										</div>
										<div class="col-md-6">
											<label>Your email address *</label>
											<input type="email" value="" data-msg-required="Please enter your email address." data-msg-email="Please enter a valid email address." maxlength="100" class="form-control" name="email" id="email">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<div class="col-md-12">
											<label>Subject</label>
											<input type="text" value="" data-msg-required="Please enter the subject." maxlength="100" class="form-control" name="subject" id="subject">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="form-group">
										<div class="col-md-12">
											<label>Message *</label>
											<textarea maxlength="5000" data-msg-required="Please enter your message." rows="10" class="form-control" name="message" id="message"></textarea>
										</div>
									</div>
								</div>
                             
                             
                               <?php ?>
                                <div class="row">
									<div class="col-md-12">
										<label>Human Verification *</label>
									</div>
								</div>
                                <div class="row">
									<div class="form-group">
										<div class="col-md-4">
											<div class="captcha form-control">
												<div class="captcha-image">
													<?php
													$_SESSION['captcha'] = simple_php_captcha(array(
														'min_length' => 6,
														'max_length' => 6,
														'min_font_size' => 22,
														'max_font_size' => 22,
														'angle_max' => 3
													));

													$_SESSION['captchaCode'] = $_SESSION['captcha']['code'];

													echo '<img src="' . "php/simple-php-captcha/simple-php-captcha.php/" . $_SESSION['captcha']['image_src'] . '" alt="CAPTCHA code">';
													?>
												</div>
											</div>
										</div>
										<div class="col-md-8">
											<input type="text" value="" maxlength="6" data-msg-captcha="Wrong verification code." data-msg-required="Please enter the verification code." placeholder="Type the verification code." class="form-control" name="captcha" id="captcha">
										</div>
									</div>
								</div>
                                
								<?php  ?>
								<div class="row">
									<div class="col-md-12">
										<input type="submit" value="Send Message" class="btn btn-primary btn-lg" data-loading-text="Loading...">
									</div>
								</div>
							</form>
						</div>
						<div class="col-md-6" id="contactus">

							<?php echo $contactus[0]['content'];?>

						</div>

					</div>

				</div>
			</div>

			<footer class="short" id="footer">
			
				<div class="footer-copyright">
					<div class="container">
						<div class="row">
							<div class="col-md-1">
								<a href="index.php" class="logo">
									<img alt="Porto Website Template" class="img-responsive" src="img/logo-footer.png">
								</a>
							</div>
							<div class="col-md-11">
								<p>© Copyright 2014. All Rights Reserved.</p>
							</div>
						</div>
					</div>
				</div>
			</footer>
		</div>

		<!-- Libs -->
		<script src="vendor/jquery.js"></script>
		<script src="vendor/jquery.appear.js"></script>
		<script src="vendor/jquery.easing.js"></script>
		<script src="vendor/jquery.cookie.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.js"></script>
		<script src="vendor/jquery.validate.js"></script>
		<script src="vendor/jquery.stellar.js"></script>
		<script src="vendor/jquery.knob.js"></script>
		<script src="vendor/jquery.gmap.js"></script>
		<script src="vendor/twitterjs/twitter.js"></script>
		<script src="vendor/isotope/jquery.isotope.js"></script>
		<script src="vendor/owl-carousel/owl.carousel.js"></script>
		<script src="vendor/jflickrfeed/jflickrfeed.js"></script>
		<script src="vendor/magnific-popup/magnific-popup.js"></script>
		<script src="vendor/mediaelement/mediaelement-and-player.js"></script>
		
		<!-- Theme Initializer -->
		<script src="js/theme.plugins.js"></script>
		<script src="js/theme.js"></script>
		
		<!-- Current Page JS -->
		<script src="vendor/rs-plugin/js/jquery.themepunch.plugins.min.js"></script>
		<script src="vendor/rs-plugin/js/jquery.themepunch.revolution.js"></script>
		<script src="vendor/circle-flip-slideshow/js/jquery.flipshow.js"></script>
		<script src="js/views/view.home.js"></script>
		<script src="js/views/view.contact.js"></script>
		
		<!-- Custom JS -->
		<script src="js/custom.js"></script>

		<!-- Google Analytics: Change UA-XXXXX-X to be your site's ID. Go to http://www.google.com/analytics/ for more information.
		<script type="text/javascript">
		
			var _gaq = _gaq || [];
			_gaq.push(['_setAccount', 'UA-12345678-1']);
			_gaq.push(['_trackPageview']);
		
			(function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
			})();
		
		</script>
		 -->

		<script src="http://maps.google.com/maps/api/js?sensor=false"></script>
		<script>

			/*
			Map Settings

				Find the Latitude and Longitude of your address:
					- http://universimmedia.pagesperso-orange.fr/geo/loc.htm
					- http://www.findlatitudeandlongitude.com/find-address-from-latitude-and-longitude/

			*/

			// Map Markers
			var mapMarkers = [{
				address: "30 harcourt street, London w1h 4aa",
				html: "<strong>UK Office</strong><br>30 harcourt street, London w1h 4aa<br><br><a href='#' onclick='mapCenterAt({latitude: 51.5196286, longitude: -0.1642323, zoom: 20}, event)'>[+] zoom here</a>",
				icon: {
					image: "img/pin.png",
					iconsize: [26, 46],
					iconanchor: [12, 46]
				}
			}];

			// Map Initial Location
			var initLatitude = 51.5196286;
			var initLongitude = -0.1642323;

			// Map Extended Settings
			var mapSettings = {
				controls: {
					panControl: true,
					zoomControl: true,
					mapTypeControl: true,
					scaleControl: true,
					streetViewControl: true,
					overviewMapControl: true
				},
				scrollwheel: false,
				markers: mapMarkers,
				latitude: initLatitude,
				longitude: initLongitude,
				zoom: 16
			};

			var map = $("#googlemaps").gMap(mapSettings);

			// Map Center At
			var mapCenterAt = function(options, e) {
				e.preventDefault();
				$("#googlemaps").gMap("centerAt", options);
			}

		</script>

	</body>
</html>
