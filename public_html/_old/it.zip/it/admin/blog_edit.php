<?php
session_start();

error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);

require_once 'classes/dataAccess.php';

$obj = dataAccess::getInstance();

if(isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id']) && $_GET['id'] != '')
{
	$id = $_GET['id'];
	
	$editImage = $obj->select("blog","*","id=?",array($id));	
}
else
{
	$obj->redirect("blog.php");	
}

$titleError ="";

$detailsError ="";

$imageError ="";

$validation = true; 

if(isset($_POST['Submit']))

{
	
		if (empty($_POST["title"])) 
		{	
		 
		 $titleError = "* Title is required";
		 
		 $validation = false;
		} 
		
		if (empty($_POST["details"])) 
		{
			$detailsError = "* Details is required";
			
			$validation = false;
		}
		
		if($validation==true)
		{
		
			$title = $_POST['title'];
			
			$details = $_POST['details'];
			
			$size = 150; // the thumbnail height

			$filedir = '../gallery/blog/full/'; // the directory for the original image
			
			$thumbdir = '../gallery/blog/thumb/'; // the directory for the thumbnail image
			
			$prefix = 'thumb_'; // the prefix to be added to the original name

			$maxfile = '2000000';
			
			$mode = '777';
			
			$userfile_name = $_FILES['image']['name'];
			
			$userfile_tmp = $_FILES['image']['tmp_name'];
			
			$userfile_size = $_FILES['image']['size'];
			
			$userfile_type = $_FILES['image']['type'];
			
			if (isset($_FILES['image']['name']) && $_FILES['image']['name'] != '') 
			{
				$prod_img = $filedir.$userfile_name;

				$prod_img_thumb = $thumbdir.$prefix.$userfile_name;
				
				$imageMoved = move_uploaded_file($userfile_tmp, $prod_img);
				
				chmod ($prod_img, octdec($mode));
				
				$sizes = getimagesize($prod_img);
				
				$type = $sizes[2];
				
				$aspect_ratio = $sizes[1]/$sizes[0]; 

				/*if ($sizes[1] <= $size)
				{
					$new_width = $sizes[0];
					$new_height = $sizes[1];
				}else{
					$new_height = $size;
					$new_width = abs($new_height/$aspect_ratio);
				}*/
				
				$new_width = $sizes[0];
				
				$new_height = $sizes[1];

				$destimg=ImageCreateTrueColor($new_width,$new_height)
					or die('Problem In Creating image');
				if ($type == 1)
				{
					$srcimg = imagecreatefromgif($prod_img);
				}
				elseif ($type == 2)
				{
					$srcimg = imagecreatefromjpeg($prod_img);
				}
				elseif ($type == 3)
				{
					$srcimg = imagecreatefrompng($prod_img);
				}
				else
				{
					$srcimg = imagecreatefromwbmp($prod_img);
				}
				if(function_exists('imagecopyresampled'))
				{
					imagecopyresampled($destimg,$srcimg,0,0,0,0,$new_width,$new_height,ImageSX($srcimg),ImageSY($srcimg))
					
					or die('Problem In resizing');
				}
				else
				{
					Imagecopyresized($destimg,$srcimg,0,0,0,0,$new_width,$new_height,ImageSX($srcimg),ImageSY($srcimg))
					
					or die('Problem In resizing');
				}
				
				if ($type == 1)
				{
					imagegif($destimg,$prod_img_thumb,90)
					or die('Problem In saving');
				}
				elseif ($type == 2)
				{
					imagejpeg($destimg,$prod_img_thumb,90)
					or die('Problem In saving');
				}
				elseif ($type == 3)
				{
					imagepng($destimg,$prod_img_thumb,0)
					or die('Problem In saving');
				}
				else
				{
					imagewbmp($destimg,$prod_img_thumb,0)
					or die('Problem In saving');
				}
				
				imagedestroy($destimg);
				
				$thumbpath = $prefix.$userfile_name;
				
			}
			else
			{
				$thumbpath =$editImage[0]['thumb']; 
				
				$userfile_name = $editImage[0]['full']; 
			}
			switch($_POST['Submit'])
			{
						case 'Update':
							
							$imagesdb = $obj->update("blog","title = '$title',thumb = '$thumbpath' , full = '$userfile_name', details = '$details', status=1 where id = ?",array($id));
							
							$obj->redirect('blog.php');
							
							break;
							
						case 'Save Draft':
							
							$imagesdb = $obj->update("blog","title = '$title',thumb = '$thumbpath' , full = '$userfile_name', details = '$details' , status=2 where id = ?",array($id));
							
							$obj->redirect('blog.php');
							
							break;
			}
		}
}
?>
<?php
include_once('header.php');
?>
<script type="text/javascript" >
 $(document).ready(function () {
	$("#preview").click(function(e){
			
			e.preventDefault();
			
			var title = $("#title").val();
			
			var details = CKEDITOR.instances.details.getData();
			
			var oldImage = $("#image1").attr('name');
			
			var image =    $('#image').val();
			
			var validate = true;
			if(title=='')
			{
				$('#titleError').html('Title is Required');
				
				validate = false;
				
			}
			else 
			{
				$('#titleError').html('');
				
			}
			if(details=='')
			{
				$('#detailsError').html('Details is Required');
				
				validate = false;
				
			}
			else
			{
				$('#detailsError').html('');
			}
			
			if(validate) 
			{
				var form = $('#uploadForm')[0];
				
				var dataString = new FormData(form);
				
				dataString.append('request', 'edit' );
				
				$.ajax({
						type: "POST",
						url:'userInfo.php',
						data: dataString, 
						processData: false,
						contentType: false,
						success : function(data) 
						{
							window.open('preview_blog.php?id='+data);
						}
					});
			}
});
});
</script>

        <div class="content_cont">
        	
            <?php include_once('left.php');?>
            
            <div class="admin_contents">
			
            <?php echo $addMsg; ?>

			<h4>Blog</h4> 
			
            <form method="post" id="uploadForm" action=""  enctype="multipart/form-data" >
                <div class="form-group">
                    <label for="text_field">Blog Title</label>
                    <input type="text" name="title"  value="<?php echo $editImage[0]['title'];?>" class="form-control" id="title" placeholder="Blog Title">
					<span id="titleError" style="color: #FF1B1B; ">  <?php echo $titleError;?></span>
                </div>
                <div class="form-group">
                    <label for="exampleInputFile">Image</label>
                    <input type="file" id="image" name="image" >
					<span><img id="oldImage"  style="width: 300px;" src="../gallery/blog/thumb/<?php echo $editImage[0]['thumb'];?>"></span>
					

					<input type="hidden" name="image1" value="<?php echo $editImage[0]['full'];  ?>" >
                    <p class="help-block">*ext .png, .jpg, .gif</p>
                </div>
               
                        <label for="contents">Details:</label>
                <textarea class="form-control ckeditor" name="details" id="details" rows="5"><?php echo $editImage[0]['details'];?></textarea>  
<span id="detailsError" style="color: #FF1B1B;" > <?php echo $detailsError;?></span>
                <br><br>   
				
                <input type="submit" id="Submit"  name="Submit" class="btn btn-primary" value="Update" /> 
				
				<input type="submit"  id="Submit" name="Submit" class="btn btn-primary" value="Save Draft" /> 
				
                 <input type="button" id="preview"  class="btn btn-primary" value="Preview" /> 
                               
            </form>   			
                
            </div><!--admin_contents -->
        </div><!--content_cont -->
       <?php include_once('footerc.php');?>
    </div><!-- container -->
</body>
</html>
