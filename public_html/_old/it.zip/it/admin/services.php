<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require_once 'classes/dataAccess.php';

$obj = dataAccess::getInstance();


if(isset($_GET['action']) && $_GET['action'] == 'del' && isset($_GET['id']) && $_GET['id'] != '')
{
	$id = $_GET['id'];
	$selectImage = $obj->select("services","*","id=?",array($id));
	$deleteImage = $obj->delete("services","id=?",array($id));
	//echo "../gallery/home/full/".$selectImage[0]['full'];
	
	unlink("../gallery/services/full/".$selectImage[0]['full']);
	unlink("../gallery/services/thumb/".$selectImage[0]['thumb']);	
	$delMsg = "Record deleted successfully";
}


//check if form is submitted

if(isset($_POST['Submit']))
{
	$title = $_POST['title'];
	$sub_title = $_POST['sub_title'];
	$main_title = $_POST['main_title'];
	$details = $_POST['details'];
	$size = 265; // the thumbnail height

	$filedir = '../gallery/services/full/'; // the directory for the original image
	$thumbdir = '../gallery/services/thumb/'; // the directory for the thumbnail image
	$prefix = 'thumb_'; // the prefix to be added to the original name

	$maxfile = '2000000';
	$mode = '0666';
	
	$userfile_name = $_FILES['image']['name'];
	$userfile_tmp = $_FILES['image']['tmp_name'];
	$userfile_size = $_FILES['image']['size'];
	$userfile_type = $_FILES['image']['type'];
	
	if (isset($_FILES['image']['name'])) 
	{
		$prod_img = $filedir.$userfile_name;

		$prod_img_thumb = $thumbdir.$prefix.$userfile_name;
		$imageMoved = move_uploaded_file($userfile_tmp, $prod_img);
		chmod ($prod_img, octdec($mode));
		
		$sizes = getimagesize($prod_img);
		$type = $sizes[2];
		$aspect_ratio = $sizes[1]/$sizes[0]; 

		/*if ($sizes[0] <= $size)
		{
			$new_width = $sizes[0];
			$new_height = $sizes[1];
		}else{
			$new_width = $size;
			$new_height = abs($new_width/$aspect_ratio);
		}
*/

		$new_width = 265;
		$new_height = 265;
		
		$destimg=ImageCreateTrueColor($new_width,$new_height)
			or die('Problem In Creating image');
		if ($type == 1)
		{
			$srcimg = imagecreatefromgif($prod_img);
		}
		elseif ($type == 2)
		{
			$srcimg = imagecreatefromjpeg($prod_img);
		}
		elseif ($type == 3)
		{
			$srcimg = imagecreatefrompng($prod_img);
		}
		else
		{
			$srcimg = imagecreatefromwbmp($prod_img);
		}

		//$srcimg=ImageCreateFromJPEG($prod_img)
			//or die('Problem In opening Source Image');
		if(function_exists('imagecopyresampled'))
		{
			imagecopyresampled($destimg,$srcimg,0,0,0,0,$new_width,$new_height,ImageSX($srcimg),ImageSY($srcimg))
			or die('Problem In resizing');
		}else{
			Imagecopyresized($destimg,$srcimg,0,0,0,0,$new_width,$new_height,ImageSX($srcimg),ImageSY($srcimg))
			or die('Problem In resizing');
		}
		
		if ($type == 1)
		{
			imagegif($destimg,$prod_img_thumb,90)
			or die('Problem In saving');
		}
		elseif ($type == 2)
		{
			imagejpeg($destimg,$prod_img_thumb,90)
			or die('Problem In saving');
		}
		elseif ($type == 3)
		{
			imagepng($destimg,$prod_img_thumb,90)
			or die('Problem In saving');
		}
		else
		{
			imagewbmp($destimg,$prod_img_thumb,90)
			or die('Problem In saving');
		}
		imagedestroy($destimg);
		
		if($imageMoved)
		{
			$imagesdb = $obj->insert("services",array("main_title"=>"$main_title","title"=>"$title","sub_title"=>"$sub_title", "thumb"=>"$prefix"."$userfile_name","full"=>"$userfile_name","details"=>"$details"));
			
			if($imagesdb)
			{
				$addMsg = "Image added successfully";	
			}
		}
		
	}
	else
	{
		echo "No image was selected.";	
	}


}


?>

<?php include_once('header.php');?>
<script>
loadData(1);
</script>
        <div class="content_cont">
        	
            <?php include_once('left.php');?>
            
            <div class="admin_contents">
            <h4>Services Page</h4>

			
            
            <form method="post" name="services-content" action="services.php" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="text_field">Service Title</label>
                    <input type="text" name="title" class="form-control" id="title" placeholder="Service Title">
                </div>
                
                <div class="form-group">
                    <label for="text_field">Main Title</label>
                    <input type="text" name="main_title" class="form-control" id="main_title" placeholder="Main Title">
                </div>
                
                <div class="form-group">
                    <label for="text_field">Service Sub Title</label>
                    <input type="text" name="sub_title" class="form-control" id="sub_title" placeholder="Service Sub Title">
                </div>
                
                <div class="form-group">
                    <label for="exampleInputFile">Image</label>
                    <input type="file" id="image" name="image">
                    <p class="help-block">*ext .png, .jpg, .gif</p>
                </div>
                
                <label for="contents">Details:</label>
                <textarea class="form-control ckeditor" name="details" id="details" rows="5"></textarea>  
                <br><br>
                <input type="submit" name="Submit" class="btn btn-primary" value="Update" /> 
                
            </form>   
			
                 <br>
             <div id="loading" align="center"><img src='images/loading.gif'/></div>
            <div class="table_outer_cont">
			
           
        
       			 
                </div>
            </div><!--admin_contents -->
        </div><!--content_cont -->
        
       <?php include_once('footerc.php');?>
        
    </div><!-- container -->

</body>
</html>
