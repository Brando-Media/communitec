<?php



require_once 'functions.php';

//check if admin is login

if(!checkAdminLogin())
{
	echo '<script>window.location = "login.php";</script>';
}

?>
<!DOCTYPE HTML>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Communitec - Admin Panel</title>
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
<link href="css/styles.css" rel="stylesheet" type="text/css">
<script src="js/jquery-1.9.1.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/common.js" type="text/javascript"></script>
<script src="js/functions.js" type="text/javascript"></script>
<script src="ckeditor/ckeditor.js" type="text/javascript"></script>

<script type="text/javascript">
    CKEDITOR.replace('textarea', {
         filebrowserBrowseUrl: 'kcfinder/browse.php?type=files',
         filebrowserImageBrowseUrl: 'kcfinder/browse.php?type=images',
         filebrowserFlashBrowseUrl: 'kcfinder/browse.php?type=flash',
         filebrowserUploadUrl: 'kcfinder/upload.php?type=files',
         filebrowserImageUploadUrl: 'kcfinder/upload.php?type=images',
         filebrowserFlashUploadUrl: 'kcfinder/upload.php?type=flash'
    });			
</script>
</head>

<body>

	<div class="container">
        <header class="header">
        	<h1 class="logo"><a href="index.php">Communitec</a><br><span>admin panel</span></h1>
            <nav class="header_nav">
            	<a href="logout.php"><i class="fa fa-sign-out"></i> Logout</a>
            </nav>
        </header>
        