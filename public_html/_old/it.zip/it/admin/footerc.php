 <footer class="footer">
        	<div class="foot_content">© Copyright 2014 - Communitec.co.uk</div>
        </footer>