<?php

session_start();

error_reporting(E_ALL ^ E_NOTICE);

require_once 'classes/dataAccess.php';




$obj = dataAccess::getInstance();





if(isset($_GET['action']) && $_GET['action'] == 'del' && isset($_GET['id']) && $_GET['id'] != '')

{

	$id = $_GET['id'];

	$selectImage = $obj->select("blog","*","id=?",array($id));

	$deleteImage = $obj->delete("blog","id=?",array($id));

	//echo "../gallery/home/full/".$selectImage[0]['full'];

	

	unlink("../gallery/blog/full/".$selectImage[0]['full']);

	unlink("../gallery/blog/thumb/".$selectImage[0]['thumb']);	
	//redirect ("blog.php");

	$delMsg = "Record deleted successfully";
	$obj->redirect("blog.php");

}




//check if form is submitted


$titleError ="";
$detailsError ="";
$imageError ="";
$title ='';
$details ='';
$image ='';

$validation = true;
		

if(isset($_POST['Submit']))
{
		
		//$title = $_POST['title'];
		//$details = $_POST['details'];
		if (empty($_POST["title"])) 
		{	
			$titleError = "* Title is required";
			$validation = false;
		} 
		
		if (empty($_POST["details"])) 
		{
			$detailsError = "* Details is required";
			$validation = false;
		}
		
		if(empty($_FILES["image"]["name"]))
		{
			$imageError = "* Image is required";
			$validation = false;
		} 
		$title = $_POST['title'];
		$details = $_POST['details'];
		$userfile_name = $_FILES['image']['name'];
	
		if($validation==true)
		{
	
	
			//$userfile_name = $_FILES['image']['name'];
			//exit;
			
			
			
			$updated_date = date('Y-m-d'); 	

			$size = 265; // the thumbnail height



			$filedir = '../gallery/blog/full/'; // the directory for the original image

			$thumbdir = '../gallery/blog/thumb/'; // the directory for the thumbnail image

			$prefix = 'thumb_'; // the prefix to be added to the original name



			$maxfile = '2000000';

			$mode = '777';

			

			$userfile_name = $_FILES['image']['name'];

			$userfile_tmp = $_FILES['image']['tmp_name']; 

			$userfile_size = $_FILES['image']['size'];

			$userfile_type = $_FILES['image']['type'];

		
		
			//echo 'inside function'; exit;
			  
			 
			 
			$prod_img = $filedir.$userfile_name;
			


			$prod_img_thumb = $thumbdir.$prefix.$userfile_name;

			$imageMoved = move_uploaded_file($userfile_tmp, $prod_img);

			chmod ($prod_img, octdec($mode));

			

			$sizes = getimagesize($prod_img);

			$type = $sizes[2];

			$aspect_ratio = $sizes[1]/$sizes[0]; 



			/*if ($sizes[0] <= $size)

			{

				$new_width = $sizes[0];

				$new_height = $sizes[1];

			}else{

				$new_width = $size;

				$new_height = abs($new_width/$aspect_ratio);

			}

	*/



				$new_width = 265;

				$new_height = 265;

				

				$destimg=ImageCreateTrueColor($new_width,$new_height)

					or die('Problem In Creating image');

				if ($type == 1)

				{

					$srcimg = imagecreatefromgif($prod_img);

				}

				elseif ($type == 2)

				{

					$srcimg = imagecreatefromjpeg($prod_img);

				}

				elseif ($type == 3)

				{

					$srcimg = imagecreatefrompng($prod_img);

				}

				else

				{

					$srcimg = imagecreatefromwbmp($prod_img);

				}



		//$srcimg=ImageCreateFromJPEG($prod_img)

			//or die('Problem In opening Source Image');

		if(function_exists('imagecopyresampled'))

		{

			imagecopyresampled($destimg,$srcimg,0,0,0,0,$new_width,$new_height,ImageSX($srcimg),ImageSY($srcimg))

			or die('Problem In resizing');

		}else{

			Imagecopyresized($destimg,$srcimg,0,0,0,0,$new_width,$new_height,ImageSX($srcimg),ImageSY($srcimg))

			or die('Problem In resizing');

		}

		

		if ($type == 1)

		{

			imagegif($destimg,$prod_img_thumb,90)

			or die('Problem In saving');

		}

		elseif ($type == 2)

		{

			imagejpeg($destimg,$prod_img_thumb,90)

			or die('Problem In saving');

		}

		elseif ($type == 3)

		{

			imagepng($destimg,$prod_img_thumb,0)

			or die('Problem In saving');

		}

		else

		{

			imagewbmp($destimg,$prod_img_thumb,0)

			or die('Problem In saving');

		}

		imagedestroy($destimg);

		

		if($imageMoved)

		{
			switch($_POST['Submit'])
			{
				
				case 'Update':
				
					$imagesdb = $obj->insert("blog",array("title"=>"$title","upload_date"=>"$updated_date","thumb"=>"$prefix"."$userfile_name","full"=>"$userfile_name","details"=>"$details","status"=>"1"));
					break;
				case 'Save Draft':
				//echo $title.'<br>'.$prefix.$userfile_name.'<br>'.$userfile_name; exit;
					$imagesdb = $obj->insert("blog",array("title"=>"$title","upload_date"=>"$updated_date","thumb"=>"$prefix"."$userfile_name","full"=>"$userfile_name","details"=>"$details","status"=>"2"));
					break;
			}

		}
	}
	$title ='';
	$details ='';
	$image ='';
}
?>





<?php include_once('header.php');?>

<script type="text/javascript" >

loadBlogData(1);

</script>
<script type="text/javascript" >
 $(document).ready(function () {
	$("#preview").click(function(e){
		 //$("#myForm").submit();
		 
			
			e.preventDefault();
			var title = $("#title").val();
			var details = CKEDITOR.instances.details.getData();
			var image = $("#image").val();
			
			//alert(print_r(file));
			//var fileName = file.name;
			//var fileTmp = file.tmp_name;
			//alert(fileTmp);
			
			//alert(details);
			//alert(image);
			//alert(file);
			//alert(fileName);
			var validate = true;
			
			if(title=='')
			{
				$('#titleError').html('Title is Required');
				validate = false;
				
			}
			else 
			{
				$('#titleError').html('');
				
			}
			if(details=='')
			{
				$('#detailsError').html('Details is Required');
				validate = false;
				
			}
			else
			{
				$('#detailsError').html('');
				
				
			}
			if(image=='')
			{
				$('#imageError').html('File is required');
				validate = false;
				
			}
			else
			{
				$('#imageError').html('');
			
			}
			if(validate)
			{
				var form = $('#uploadForm')[0];
				
				var dataString = new FormData(form);
				dataString.append('request', 'update' );
				//dataString.append(details, 'details' );
				/*var fd = new FormData();    
				fd.append( 'title', title );
				fd.append( 'image', $("#image")[0].files[0] );*/
				dataString.append( 'details', details );
				$('#loading2').show();
				
				$.ajax({
							type: "POST",
							url: 'userInfo.php',
							enctype: 'multipart/form-data',
							data: dataString,
							processData: false,
							contentType: false,
							//data: {'title': title, 'details': details, 'fileName': fileName}, 
							success : function(data) 
							{
								
								window.open('preview_blog.php?id='+data);
								$('#loading2').hide();
								
								
							}	 
				});
			}
});
});



</script>



        <div class="content_cont">

        	

            <?php include_once('left.php');?>

            

            <div class="admin_contents">

            <h4>Blog Page</h4>


            <form id="uploadForm" method="post" name="services-content" action="blog.php" enctype="multipart/form-data">

                <div class="form-group">

                    <label for="text_field">Blog Title</label>

                    <input type="text" name="title" class="form-control" value="<?php echo $title; ?>" id="title" placeholder="Blog Title">
						<span id="titleError" style="color: #FF1B1B; ">  <?php echo $titleError;?></span>
                </div>

				<div class="form-group">

                    <label for="exampleInputFile">Image</label>

                    <input type="file" id="image" name="image">
					<span id="imageError" style="color: #FF1B1B;" ><?php echo $imageError;?></span>
                    <p class="help-block">*ext .png, .jpg, .gif</p>
					

                </div>

                
                

                <label for="contents">Details:</label>

                <textarea class="form-control ckeditor" name="details" id="details" rows="5"><?php echo $details; ?></textarea>  
					<span id="detailsError" style="color: #FF1B1B;" > <?php echo $detailsError;?></span>
                <br><br>

                <input type="submit" id="update" name="Submit" class="btn btn-primary" value="Update" /> 
				
				<input type="submit" id="draft" name="Submit" class="btn btn-primary" value="Save Draft" /> 
				
                <input type="button"  id="preview"  class="btn btn-primary" value="Preview" /> 
				<img id="loading2" style="display:none" src='images/loading.gif'/>


            </form>   

			

                 <br>

             <div id="loading" align="center"><img src='images/loading.gif'/></div>

            <div class="table_outer_cont">

			
        

       			 

                </div>

            </div><!--admin_contents -->

        </div><!--content_cont -->

        

       <?php include_once('footerc.php');?>

        

    </div><!-- container -->



</body>

</html>

