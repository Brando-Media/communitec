<?php
session_start();
require_once 'classes/dataAccess.php';
//error_reporting(E_ALL ^ E_NOTICE);
$obj = dataAccess::getInstance();


if($_POST['username'])
{
	$username = $_POST['username'];
	$password = $_POST['password'];	
	//$login = $obj->query("select * from users where username='$username' and password = '$password'");
	$login = $obj->select("users","*","username=? and password = ? ",array($username,$password));
	//print_r($login);
	if(count((array)$login)==1)
	{
		$_SESSION['userid'] = $login[0]['id'];
		$_SESSION['username'] = $login[0]['username'];
		print('successful');	
	}
	else {
			print('unsuccessful');
		}
	
}
