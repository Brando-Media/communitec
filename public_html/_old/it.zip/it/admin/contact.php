<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require_once 'classes/dataAccess.php';

$obj = dataAccess::getInstance();


//if form is posted
if($_POST['content'])
{
	$content = addslashes($_POST['content']);
	$updated_time = date('Y-m-d H:i:s');	
	$contents = $obj->update("contactus","content = '$content' where id=?",array(1));
	
	if($contents)
	{
		
		$update_msg = "Content updated successfully!";
	}
}

//show updated content in editor
$cons_content = $obj->select("contactus","*","id = ?",array(1));
?>
<?php include_once('header.php');?>


        <div class="content_cont">
        	
            <?php include_once('left.php');?>
            
            <div class="admin_contents">
            <h4>Contact Us Page</h4>

			<?php if($update_msg != '')
				  {
					echo $update_msg;
				  }?>
			
            
            <form method="post" name="about-content" action="contact.php" enctype="multipart/form-data">
                
                <label for="contents">Contents:</label>
                <textarea class="form-control ckeditor" name="content" id="content" rows="5"><?php echo $cons_content[0]['content'];?></textarea>  
                <br><br>
                <input type="submit" class="btn btn-primary" value="Update" /> 
                
            </form>   
			
                
            </div><!--admin_contents -->
        </div><!--content_cont -->
        
       <?php include_once('footerc.php');?>
        
    </div><!-- container -->

</body>
</html>
