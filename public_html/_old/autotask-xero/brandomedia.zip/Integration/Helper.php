<?php
namespace Integration;

class Helper {
  
  protected static $map_contact_autotask_xero  = array (
    'Active' => '', 
    'AdditionalAddressInformation' => '', 
    'AddressLine' => '', 
    'AddressLine1' => '', 
    'AlternatePhone' => '', 
    'City' => '', 
    'Country' => '', 
    'EMailAddress' => 'EmailAddress', 
    'FaxNumber' => '', 
    'FirstName' => 'FirstName', 
    'LastName' => 'LastName', 
    'MobilePhone' => '', 
    'Phone' => '', 
    'State' => '', 
    'ZipCode' => '', 
    'id' => 'ContactNumber', 
  );
  
  public static function map_contact_autotask_xero($at_contact) {
    $x_contact  = array();
    //new dBug($at_contact, '', 1);
    foreach (self::$map_contact_autotask_xero as $at_field => $x_field) {
      if (property_exists($at_contact, $at_field)) {
        $x_contact[$x_field]  = $at_contact->{$at_field};
      }
    }
    // Address
    $x_contact['ContactStatus']  = $at_contact->Active ? 'ACTIVE' : 'ARCHIVED';
    $x_contact['Name']  = trim($at_contact->FirstName. " " .$at_contact->LastName);
    $x_contact['Addresses'] = array (
      array (
        'AddressLine1'  => $at_contact->AddressLine,
        'AddressLine2'  => $at_contact->AddressLine1,
        'AddressLine3'  => $at_contact->AdditionalAddressInformation,
        'City'  => $at_contact->City,
        'Region'  => $at_contact->State,
        'PostalCode'  => $at_contact->ZipCode,
        'Country'  => $at_contact->Country,
      ),
    );
    // Phones
    $x_contact['Phones']  = array (
      array (
        'PhoneNumber' => $at_contact->AlternatePhone, 
        'PhoneType'   => 'DDI', 
      ),
      array (
        'PhoneNumber' => $at_contact->Phone, 
        'PhoneType'   => 'DEFAULT', 
      ),
      array (
        'PhoneNumber' => $at_contact->MobilePhone, 
        'PhoneType'   => 'MOBILE', 
      ),
      array (
        'PhoneNumber' => $at_contact->FaxNumber, 
        'PhoneType'   => 'FAX', 
      ),
    );
    
    return $x_contact;
  }

}
