<?php
namespace Integration\Xero;

class Exception extends \Exception {
  const CODE_INVALID_RESPONSE = 3000;
}
