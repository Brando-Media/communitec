<?php
namespace Integration\Autotask;

class Exception extends \Exception {
  const CODE_INVALID_RESPONSE = 3000;
}
