<?php
require_once __DIR__ . '/config.php';
require_once 'dBug.php';

$autotask_contact = new \Integration\Autotask\Contact();
$date = date('Y-m-d H:i:s', strtotime('-1 HOUR'));
//$date  = '2016-06-02 07:56:45';
$at_contacts  = $autotask_contact->get_modified($date);
new dBug($at_contacts, '', 1);
if ( ! is_array($at_contacts) || count($at_contacts) == 0) {
  exit;
}

$XeroContact = new \Integration\Xero\Contact();
foreach ($at_contacts as $at_contact) {
  $data[] = \Integration\Helper::map_contact_autotask_xero($at_contact);
}
try {
  $x_contacts = $XeroContact->add_multiple($data);
} catch (\Integration\Xero\Exception $e) {
  echo($e->getMessage());
}
new dBug($x_contacts, '', 1);

