<?php
error_reporting(E_ALL & ~E_STRICT & ~E_DEPRECATED & ~E_NOTICE & ~E_WARNING);
require_once __DIR__ . '/config.php';

$autotask_contact = new \Integration\Autotask\Contact();
$date = date('Y-m-d H:i:s', strtotime('-1 HOUR'));
$at_contacts  = $autotask_contact->get_modified($date);
if ( ! is_array($at_contacts) || count($at_contacts) == 0) {
  exit;
}

$XeroContact = new \Integration\Xero\Contact();
foreach ($at_contacts as $at_contact) {
  $data[] = \Integration\Helper::map_contact_autotask_xero($at_contact);
}
try {
  $x_contacts = $XeroContact->add_multiple($data);
} catch (\Integration\Xero\Exception $e) {
  echo($e->getMessage());
}
